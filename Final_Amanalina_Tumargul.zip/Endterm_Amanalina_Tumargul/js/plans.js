/* =========================================================
   plans.js — membership cards (from data) and the
   "which plan is cheapest?" calculator.
   ========================================================= */
(function (L) {
  'use strict';

  var grid = L.qs('#planGrid');
  if (!grid) { return; }

  /* ---- 1. Build the plan cards ---- */
  L.data.plans.forEach(function (plan) {
    var list = L.el('ul', {}, plan.perks.map(function (perk) { return L.el('li', { text: perk }); }));
    var price = L.el('div', { class: 'price' }, [L.money(plan.price)]);
    if (plan.unit) { price.appendChild(L.el('small', { text: ' ' + plan.unit })); }

    var card = L.el('article', { class: 'plan reveal' + (plan.featured ? ' featured' : ''), 'data-plan': plan.id }, [
      plan.featured ? L.el('span', { class: 'ribbon', text: 'Most loved' }) : null,
      L.el('h3', { text: plan.name }),
      L.el('p', { text: plan.tagline }),
      price,
      list,
      L.el('a', { class: 'btn ' + (plan.featured ? 'btn-liara' : 'btn-outline-liara'), href: '#booking', text: plan.cta })
    ]);
    grid.appendChild(card);
  });

  /* ---- 2. Calculator ---- */
  var countInput = L.qs('#calcCount');
  var rangeInput = L.qs('#calcRange');
  var error = L.qs('#calcError');
  var result = L.qs('#calcResult');

  var MIN = 1, MAX = 30;

  // Cost per month for n classes under each plan
  function monthlyCosts(n) {
    var byId = {};
    L.data.plans.forEach(function (plan) { byId[plan.id] = plan; });
    var passesIn3Months = Math.ceil((n * 3) / 10);           // a pass has 10 classes and lasts 3 months
    return [
      { id: 'dropin',    name: byId.dropin.name,    cost: n * byId.dropin.price },
      { id: 'pass10',    name: byId.pass10.name,    cost: (passesIn3Months * byId.pass10.price) / 3 },
      { id: 'unlimited', name: byId.unlimited.name, cost: byId.unlimited.price }
    ];
  }

  function showError(message) {
    error.textContent = message;
    error.hidden = !message;
    countInput.classList.toggle('is-invalid', !!message);
    countInput.setAttribute('aria-invalid', message ? 'true' : 'false');
  }

  function clearBest() {
    L.qsa('.plan', grid).forEach(function (card) { card.classList.remove('is-best'); });
  }

  function calculate(source) {
    var raw = String(countInput.value).trim();
    var n = Number(raw);

    if (raw === '') { showError('Enter how many classes you plan to take each month.'); }
    else if (!Number.isInteger(n)) { showError('Use a whole number, for example 8.'); }
    else if (n < MIN || n > MAX) { showError('Choose a number from ' + MIN + ' to ' + MAX + '.'); }
    else { showError(''); }

    if (error.hidden === false) {
      result.textContent = '';
      clearBest();
      return;
    }

    if (source !== 'range') { rangeInput.value = n; }
    var costs = monthlyCosts(n);
    var best = costs.reduce(function (a, b) { return b.cost < a.cost ? b : a; });
    var dropin = costs[0];

    result.textContent = '';
    costs.forEach(function (item) {
      var row = L.el('li', { class: 'calc-row' + (item.id === best.id ? ' is-best' : '') }, [
        L.el('span', { text: item.name }),
        L.el('strong', { text: L.money(item.cost) + ' / month' }),
        item.id === best.id ? L.el('span', { class: 'best-tag', text: 'Best value' }) : null
      ]);
      result.appendChild(row);
    });

    var saving = dropin.cost - best.cost;
    var note = saving > 0
      ? 'With ' + best.name + ' you save ' + L.money(saving) + ' a month compared with drop-in.'
      : 'At this pace drop-in is the best fit: no commitment, pay only when you come.';
    result.appendChild(L.el('li', { class: 'calc-note', text: note }));

    clearBest();
    var bestCard = L.qs('.plan[data-plan="' + best.id + '"]', grid);
    if (bestCard) { bestCard.classList.add('is-best'); }
  }

  countInput.addEventListener('input', function () { calculate('number'); });
  rangeInput.addEventListener('input', function () { countInput.value = rangeInput.value; calculate('range'); });
  // Arrow keys on the number field already work; Enter should not submit anything
  countInput.addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); } });

  calculate('init');
})(window.Liara);
