/* =========================================================
   schedule.js — searchable, filterable, sortable timetable.
   Rows are created from Liara.data.classes with DOM methods.
   ========================================================= */
(function (L) {
  'use strict';

  var form = L.qs('#scheduleControls');
  if (!form) { return; }

  var tbody = L.qs('#scheduleBody');
  var tableWrap = L.qs('#scheduleTable');
  var emptyBox = L.qs('#scheduleEmpty');
  var summary = L.qs('#scheduleSummary');
  var searchInput = L.qs('#scheduleSearch');
  var daySelect = L.qs('#filterDay');
  var levelSelect = L.qs('#filterLevel');
  var freeOnly = L.qs('#filterFree');
  var sortSelect = L.qs('#sortBy');

  var classes = L.data.classes;

  /* ---- Prepare: add the next date and free places to every class ---- */
  function withNextSession(cls) {
    var date = L.nextSession(cls.weekday, cls.time);
    var iso = L.toISO(date);
    return Object.assign({}, cls, { nextDate: date, nextISO: iso, left: L.spotsLeft(cls, iso) });
  }

  /* ---- Filtering ---- */
  function matches(cls, filters) {
    var haystack = (cls.name + ' ' + cls.teacher + ' ' + cls.day).toLowerCase();
    if (filters.text && haystack.indexOf(filters.text) === -1) { return false; }
    if (filters.day !== 'all' && String(cls.weekday) !== filters.day) { return false; }
    if (filters.level !== 'all' && cls.level !== filters.level) { return false; }
    if (filters.free && cls.left === 0) { return false; }
    return true;
  }

  /* ---- Sorting ---- */
  function weekOrder(cls) { return (cls.weekday + 6) % 7; } // Monday first, Sunday last

  function sortList(list, mode) {
    var sorted = list.slice();
    sorted.sort(function (a, b) {
      if (mode === 'spots' && b.left !== a.left) { return b.left - a.left; }
      if (mode === 'name') {
        var byName = a.name.localeCompare(b.name);
        if (byName !== 0) { return byName; }
      }
      if (weekOrder(a) !== weekOrder(b)) { return weekOrder(a) - weekOrder(b); }
      return a.time.localeCompare(b.time);
    });
    return sorted;
  }

  /* ---- Building one table row ---- */
  function cell(label, content, className) {
    var td = L.el('td', { 'data-label': label, class: className });
    if (typeof content === 'string') { td.textContent = content; } else { td.appendChild(content); }
    return td;
  }

  function spotsCell(cls) {
    var full = cls.left === 0;
    var low = cls.left > 0 && cls.left <= 3;
    var percent = Math.round(((cls.capacity - cls.left) / cls.capacity) * 100);
    var label = full ? 'Full' : cls.left + ' left';
    var meter = L.el('span', { class: 'meter', 'aria-hidden': 'true' }, [
      L.el('span', { class: 'meter-fill' + (full ? ' is-full' : low ? ' is-low' : ''), style: 'width:' + percent + '%' })
    ]);
    var text = L.el('span', { class: 'spots-text' + (full ? ' is-full' : low ? ' is-low' : ''), text: label });
    return L.el('span', { class: 'spots' }, [text, meter]);
  }

  function buildRow(cls) {
    var tr = L.el('tr', { 'data-id': cls.id });

    var dayTh = L.el('th', { scope: 'row', 'data-label': 'Day' }, [
      cls.day,
      L.el('small', { class: 'next-date', text: 'Next: ' + L.shortDate(cls.nextDate) })
    ]);
    tr.appendChild(dayTh);
    tr.appendChild(cell('Time', cls.time));
    tr.appendChild(cell('Class', cls.name + ' · ' + cls.duration + ' min'));
    tr.appendChild(cell('Teacher', cls.teacher));

    var level = L.LEVELS[cls.level];
    tr.appendChild(cell('Level', L.el('span', { class: 'badge-level ' + level.css, text: level.label })));
    tr.appendChild(cell('Spots', spotsCell(cls)));

    var button = L.el('button', {
      type: 'button',
      class: 'btn btn-sm btn-liara btn-book',
      'data-class': cls.id,
      'aria-label': (cls.left === 0 ? 'Class full: ' : 'Book ') + cls.name + ' on ' + cls.day + ' at ' + cls.time,
      text: cls.left === 0 ? 'Full' : 'Book'
    });
    if (cls.left === 0) { button.disabled = true; }
    tr.appendChild(cell('', button, 'cell-action'));
    return tr;
  }

  /* ---- Render everything ---- */
  function render() {
    var filters = {
      text: searchInput.value.trim().toLowerCase(),
      day: daySelect.value,
      level: levelSelect.value,
      free: freeOnly.checked
    };

    var all = classes.map(withNextSession);
    var visible = sortList(all.filter(function (cls) { return matches(cls, filters); }), sortSelect.value);

    tbody.textContent = '';
    visible.forEach(function (cls) { tbody.appendChild(buildRow(cls)); });

    var freeSpots = visible.reduce(function (sum, cls) { return sum + cls.left; }, 0);
    var isEmpty = visible.length === 0;
    tableWrap.hidden = isEmpty;
    emptyBox.hidden = !isEmpty;
    summary.textContent = isEmpty
      ? 'No classes found'
      : 'Showing ' + visible.length + ' of ' + all.length + ' classes · ' + L.plural(freeSpots, 'free spot', 'free spots') + ' in the next sessions';
  }

  /* ---- Events ---- */
  form.addEventListener('input', render);   // typing and selects
  form.addEventListener('change', render);  // checkbox and selects
  form.addEventListener('submit', function (event) { event.preventDefault(); });

  function reset() {
    form.reset();
    render();
    searchInput.focus();
  }
  L.qs('#scheduleReset').addEventListener('click', reset);
  L.qs('#scheduleEmptyReset').addEventListener('click', reset);

  // Escape clears the search box quickly
  searchInput.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && searchInput.value) { searchInput.value = ''; render(); }
  });

  // "Book" buttons (one listener for the whole table)
  tbody.addEventListener('click', function (event) {
    var button = event.target.closest('.btn-book');
    if (!button || button.disabled) { return; }
    document.dispatchEvent(new CustomEvent('liara:choose-class', { detail: { id: button.getAttribute('data-class') } }));
  });

  // Spots change when the visitor books or cancels
  document.addEventListener('liara:bookings', render);

  // Link from the Home page: classes.html?q=Dana
  var preset = new URLSearchParams(window.location.search).get('q');
  if (preset) { searchInput.value = preset.slice(0, 40); }

  render();
})(window.Liara);
