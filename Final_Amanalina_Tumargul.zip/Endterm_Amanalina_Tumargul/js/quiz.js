/* =========================================================
   quiz.js — "Which class is yours?" (Home page).
   Questions and results come from Liara.data; the score of every
   practice is calculated from the chosen answers.
   ========================================================= */
(function (L) {
  'use strict';

  var root = L.qs('#quiz');
  if (!root) { return; }

  var questions = L.data.quiz;
  var results = L.data.results;
  var current = 0;
  var chosen = [];   // chosen[i] = index of the answer for question i

  /* ---- Score calculation ---- */
  function totals() {
    var score = {};
    results.forEach(function (item) { score[item.key] = 0; });
    chosen.forEach(function (answerIndex, q) {
      var points = questions[q].answers[answerIndex].points;
      Object.keys(points).forEach(function (key) { score[key] += points[key]; });
    });
    return score;
  }

  // The most points any practice could earn from the answers that were chosen
  function ceiling() {
    return chosen.reduce(function (sum, answerIndex, q) {
      var points = questions[q].answers[answerIndex].points;
      return sum + Math.max.apply(null, Object.keys(points).map(function (key) { return points[key]; }));
    }, 0);
  }

  // Practices sorted from best to worst match; percent = score / ceiling
  function ranking() {
    var score = totals();
    var max = ceiling();
    return results.map(function (item) {
      return { item: item, score: score[item.key], percent: max ? Math.round((score[item.key] / max) * 100) : 0 };
    }).sort(function (a, b) { return b.score - a.score; });
  }

  /* ---- Question screen ---- */
  function showQuestion() {
    var q = questions[current];
    root.textContent = '';

    var progress = L.el('div', { class: 'quiz-progress', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(questions.length), 'aria-valuenow': String(current + 1), 'aria-label': 'Quiz progress' }, [
      L.el('span', { class: 'quiz-progress-fill', style: 'width:' + ((current + 1) / questions.length) * 100 + '%' })
    ]);

    var fieldset = L.el('fieldset', { class: 'quiz-fieldset' }, [
      L.el('legend', { class: 'quiz-question', text: q.question })
    ]);
    q.answers.forEach(function (answer, index) {
      var id = 'quiz-' + current + '-' + index;
      var input = L.el('input', { type: 'radio', name: 'quiz-answer', id: id, value: String(index), class: 'quiz-radio' });
      if (chosen[current] === index) { input.checked = true; }
      fieldset.appendChild(L.el('div', { class: 'quiz-option' }, [
        input,
        L.el('label', { for: id }, [L.el('span', { class: 'quiz-key', 'aria-hidden': 'true', text: String(index + 1) }), answer.text])
      ]));
    });

    var error = L.el('p', { class: 'quiz-error', id: 'quizError', role: 'alert', hidden: true, text: 'Choose an answer to continue.' });
    var back = L.el('button', { type: 'button', class: 'btn btn-outline-liara', id: 'quizBack', text: 'Back' });
    if (current === 0) { back.disabled = true; }
    var next = L.el('button', { type: 'button', class: 'btn btn-liara', id: 'quizNext', text: current === questions.length - 1 ? 'See my class' : 'Next' });

    root.appendChild(L.el('p', { class: 'quiz-step', text: 'Question ' + (current + 1) + ' of ' + questions.length }));
    root.appendChild(progress);
    root.appendChild(fieldset);
    root.appendChild(error);
    root.appendChild(L.el('div', { class: 'quiz-actions' }, [back, next]));
  }

  /* ---- Result screen ---- */
  function showResult() {
    var ranks = ranking();
    var top = ranks[0];
    root.textContent = '';

    var bars = L.el('ul', { class: 'match-list', 'aria-label': 'Match for each class' });
    ranks.slice(0, 3).forEach(function (rank) {
      bars.appendChild(L.el('li', {}, [
        L.el('span', { class: 'match-name', text: rank.item.name }),
        L.el('span', { class: 'match-bar', 'aria-hidden': 'true' }, [L.el('span', { class: 'match-fill', style: 'width:' + rank.percent + '%' })]),
        L.el('span', { class: 'match-percent', text: rank.percent + '%' })
      ]));
    });

    root.appendChild(L.el('div', { class: 'quiz-result', tabindex: '-1', id: 'quizResult' }, [
      L.el('p', { class: 'quiz-step', text: 'Your best match · ' + top.percent + '%' }),
      L.el('h3', { text: top.item.name }),
      L.el('p', { text: top.item.text }),
      bars,
      L.el('div', { class: 'quiz-actions' }, [
        L.el('a', { class: 'btn btn-liara', href: 'classes.html?class=' + top.item.classId + '#booking', text: 'Book ' + top.item.name }),
        L.el('button', { type: 'button', class: 'btn btn-outline-liara', id: 'quizRetake', text: 'Take the quiz again' })
      ])
    ]));
    L.qs('#quizResult').focus();
  }

  /* ---- Events ---- */
  function next() {
    var picked = L.qs('input[name="quiz-answer"]:checked', root);
    if (!picked) {
      L.qs('#quizError').hidden = false;
      return;
    }
    chosen[current] = Number(picked.value);
    if (current < questions.length - 1) { current += 1; showQuestion(); }
    else { showResult(); }
  }

  root.addEventListener('click', function (event) {
    var id = event.target.id;
    if (id === 'quizNext') { next(); }
    if (id === 'quizBack' && current > 0) { current -= 1; showQuestion(); }
    if (id === 'quizRetake') { current = 0; chosen = []; showQuestion(); }
  });

  // Choosing an answer hides the error message
  root.addEventListener('change', function (event) {
    if (event.target.name === 'quiz-answer') { L.qs('#quizError').hidden = true; }
  });

  // Keys 1-4 pick an answer, Enter goes on
  root.addEventListener('keydown', function (event) {
    var radios = L.qsa('input[name="quiz-answer"]', root);
    if (!radios.length) { return; }
    var number = Number(event.key);
    if (number >= 1 && number <= radios.length) {
      radios[number - 1].checked = true;
      radios[number - 1].dispatchEvent(new Event('change', { bubbles: true }));
      radios[number - 1].focus();
    } else if (event.key === 'Enter' && event.target.type === 'radio') {
      event.preventDefault();
      next();
    }
  });

  showQuestion();
})(window.Liara);
