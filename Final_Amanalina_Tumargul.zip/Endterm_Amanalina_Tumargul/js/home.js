/* =========================================================
   home.js — Home page content built from arrays:
   practice cards, stats (calculated) and the reviews slider.
   ========================================================= */
(function (L) {
  'use strict';

  /* ---------- 1. Practice cards ---------- */
  var cardBox = L.qs('#practiceGrid');
  if (cardBox) {
    L.data.practices.forEach(function (p) {
      var level = L.LEVELS[p.level];
      cardBox.appendChild(L.el('article', { class: 'practice-card reveal' }, [
        L.el('span', { class: 'icon', 'aria-hidden': 'true', text: p.icon }),
        L.el('h3', { text: p.name }),
        L.el('p', { text: p.text }),
        L.el('span', { class: 'meta' }, [p.duration + ' min · ', L.el('span', { class: 'badge-level ' + level.css, text: level.label })])
      ]));
    });
  }

  /* ---------- 2. Stats: numbers are calculated from the data ---------- */
  var statBox = L.qs('#statGrid');
  if (statBox) {
    var classes = L.data.classes;
    var teachers = {};
    classes.forEach(function (c) { teachers[c.teacher] = true; });
    var maxPeople = Math.max.apply(null, classes.map(function (c) { return c.capacity; }));

    [
      { value: Object.keys(teachers).length, label: 'certified teachers' },
      { value: classes.length,               label: 'classes every week' },
      { value: maxPeople,                    label: 'people max per class' },
      { value: 1,                            label: 'free trial class' }
    ].forEach(function (stat) {
      statBox.appendChild(L.el('div', { class: 'stat reveal' }, [
        L.el('strong', { 'data-count': String(stat.value), text: String(stat.value) }),
        L.el('span', { text: stat.label })
      ]));
    });
  }

  /* ---------- 3. Reviews slider ---------- */
  var slider = L.qs('#reviews');
  if (!slider) { return; }

  var $ = window.jQuery;
  var reviews = L.data.reviews;
  var stage = L.qs('#reviewStage');
  var dots = L.qs('#reviewDots');
  var current = 0;
  var busy = false;
  var timer = null;

  var average = reviews.reduce(function (sum, r) { return sum + r.rating; }, 0) / reviews.length;
  L.qs('#reviewAverage').textContent = average.toFixed(1) + ' average · ' + reviews.length + ' sample reviews';

  function stars(n) { return '★★★★★'.slice(0, n) + '☆☆☆☆☆'.slice(0, 5 - n); }

  function buildSlide(r) {
    return L.el('figure', { class: 'review' }, [
      L.el('p', { class: 'review-stars', 'aria-label': r.rating + ' out of 5 stars', text: stars(r.rating) }),
      L.el('blockquote', { text: '“' + r.text + '”' }),
      L.el('figcaption', { text: r.name + ' · ' + r.className + ' · member since ' + r.since })
    ]);
  }

  reviews.forEach(function (r, index) {
    dots.appendChild(L.el('button', { type: 'button', class: 'dot', 'data-index': String(index), 'aria-label': 'Show review ' + (index + 1) + ' of ' + reviews.length }));
  });

  function markDot() {
    L.qsa('.dot', dots).forEach(function (dot, index) {
      dot.classList.toggle('is-active', index === current);
      if (index === current) { dot.setAttribute('aria-current', 'true'); } else { dot.removeAttribute('aria-current'); }
    });
  }

  // Fade the old review out, put the new one in, fade it in.
  function show(index) {
    if (busy) { return; }                       // ignore clicks while a fade is running
    index = (index + reviews.length) % reviews.length;
    if (index === current && stage.firstChild) { return; }
    busy = true;
    var $stage = $(stage);
    $stage.stop(true, true).fadeOut(stage.firstChild ? 250 : 0, function () {
      stage.textContent = '';
      stage.appendChild(buildSlide(reviews[index]));
      current = index;
      markDot();
      $stage.fadeIn(350, function () { busy = false; });
    });
  }

  function play() {
    stop();
    if (!L.reducedMotion()) { timer = window.setInterval(function () { show(current + 1); }, 8000); }
  }
  function stop() { if (timer) { window.clearInterval(timer); timer = null; } }

  L.qs('#reviewPrev').addEventListener('click', function () { show(current - 1); play(); });
  L.qs('#reviewNext').addEventListener('click', function () { show(current + 1); play(); });
  dots.addEventListener('click', function (event) {
    var dot = event.target.closest('.dot');
    if (dot) { show(Number(dot.getAttribute('data-index'))); play(); }
  });
  slider.addEventListener('keydown', function (event) {
    if (event.key === 'ArrowRight') { show(current + 1); play(); }
    if (event.key === 'ArrowLeft') { show(current - 1); play(); }
  });
  // Pause while the visitor reads
  slider.addEventListener('mouseenter', stop);
  slider.addEventListener('mouseleave', play);
  slider.addEventListener('focusin', stop);
  slider.addEventListener('focusout', play);

  show(0);
  play();
})(window.Liara);
