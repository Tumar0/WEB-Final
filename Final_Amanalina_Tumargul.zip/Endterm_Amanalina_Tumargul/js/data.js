/* =========================================================
   data.js — all website content that JavaScript builds on the page.
   Every list is an array of objects; the pages create HTML from it.
   ========================================================= */
window.Liara = window.Liara || {};

(function (L) {
  'use strict';

  L.LEVELS = {
    all:          { label: 'All levels',   css: 'lvl-all' },
    beginner:     { label: 'Beginner',     css: 'lvl-beg' },
    intermediate: { label: 'Intermediate', css: 'lvl-mid' },
    advanced:     { label: 'Advanced',     css: 'lvl-adv' }
  };

  L.data = {};

  /* ---------- Weekly timetable (12 classes) ----------
     weekday: 0 = Sunday ... 6 = Saturday (same as Date.getDay())
     booked:  places already taken in the next session                     */
  L.data.classes = [
    { id: 'mon-morning', name: 'Morning Flow',              day: 'Monday',    weekday: 1, time: '07:30', teacher: 'Aigerim', level: 'all',          duration: 60, capacity: 12, booked: 7  },
    { id: 'mon-evening', name: 'Evening Restore',           day: 'Monday',    weekday: 1, time: '19:30', teacher: 'Madina',  level: 'beginner',     duration: 60, capacity: 12, booked: 9  },
    { id: 'tue-power',   name: 'Power Hatha',               day: 'Tuesday',   weekday: 2, time: '19:00', teacher: 'Dana',    level: 'intermediate', duration: 75, capacity: 12, booked: 10 },
    { id: 'wed-morning', name: 'Morning Flow',              day: 'Wednesday', weekday: 3, time: '07:30', teacher: 'Aigerim', level: 'all',          duration: 60, capacity: 12, booked: 5  },
    { id: 'wed-evening', name: 'Evening Restore',           day: 'Wednesday', weekday: 3, time: '19:30', teacher: 'Madina',  level: 'beginner',     duration: 60, capacity: 12, booked: 6  },
    { id: 'thu-power',   name: 'Power Hatha',               day: 'Thursday',  weekday: 4, time: '19:00', teacher: 'Dana',    level: 'intermediate', duration: 75, capacity: 12, booked: 8  },
    { id: 'fri-morning', name: 'Morning Flow',              day: 'Friday',    weekday: 5, time: '07:30', teacher: 'Aigerim', level: 'all',          duration: 60, capacity: 12, booked: 4  },
    { id: 'fri-vinyasa', name: 'Advanced Vinyasa',          day: 'Friday',    weekday: 5, time: '18:30', teacher: 'Aigerim', level: 'advanced',     duration: 90, capacity: 12, booked: 12 },
    { id: 'sat-power',   name: 'Power Hatha',               day: 'Saturday',  weekday: 6, time: '10:00', teacher: 'Dana',    level: 'intermediate', duration: 75, capacity: 12, booked: 11 },
    { id: 'sat-mobility',name: 'Mobility for Desk Workers', day: 'Saturday',  weekday: 6, time: '12:00', teacher: 'Dana',    level: 'beginner',     duration: 60, capacity: 12, booked: 3  },
    { id: 'sun-slow',    name: 'Slow Sunday Flow',          day: 'Sunday',    weekday: 0, time: '11:00', teacher: 'Madina',  level: 'all',          duration: 75, capacity: 12, booked: 6  },
    { id: 'sun-evening', name: 'Evening Restore',           day: 'Sunday',    weekday: 0, time: '18:00', teacher: 'Madina',  level: 'beginner',     duration: 60, capacity: 12, booked: 2  }
  ];

  /* ---------- Practices shown as cards on the Home page ---------- */
  L.data.practices = [
    { key: 'morning',   name: 'Morning Flow',              icon: '🌅', duration: 60, level: 'all',          text: 'A gentle vinyasa that wakes up the spine and sets a calm tone for the day.' },
    { key: 'power',     name: 'Power Hatha',               icon: '🔥', duration: 75, level: 'intermediate', text: 'Longer holds and strong standing poses. Build strength, balance and focus without rushing.' },
    { key: 'evening',   name: 'Evening Restore',           icon: '🌙', duration: 60, level: 'beginner',     text: 'Supported poses, soft light and breathwork to release the tension of a long working day.' },
    { key: 'mobility',  name: 'Mobility for Desk Workers', icon: '🪑', duration: 60, level: 'beginner',     text: 'Targeted stretches for the neck, shoulders and lower back, made for people who sit all day.' },
    { key: 'slow',      name: 'Slow Sunday Flow',          icon: '🍃', duration: 75, level: 'all',          text: 'An unhurried weekend practice that links breath and movement and ends with a long rest.' },
    { key: 'advanced',  name: 'Advanced Vinyasa',          icon: '✨', duration: 90, level: 'advanced',     text: 'Inversions, arm balances and flowing sequences for students with a steady practice.' }
  ];

  /* ---------- Class finder quiz ----------
     Each answer adds points to one or more practices (keys above). */
  L.data.quiz = [
    {
      question: 'How does your body feel at the end of the workday?',
      answers: [
        { text: 'Stiff neck and sore back',           points: { mobility: 3, evening: 1 } },
        { text: 'Tired, but my mind keeps racing',    points: { evening: 3, slow: 1 } },
        { text: 'Restless, I need to burn energy',    points: { power: 3, advanced: 1 } },
        { text: 'Fine, I just want to keep moving',   points: { morning: 2, slow: 1, advanced: 1 } }
      ]
    },
    {
      question: 'How much yoga have you done?',
      answers: [
        { text: 'Never tried it',                     points: { evening: 2, mobility: 2, morning: 1 } },
        { text: 'A few classes here and there',       points: { morning: 2, slow: 2, mobility: 1 } },
        { text: 'I practise regularly',               points: { power: 3, slow: 1 } },
        { text: 'Years of steady practice',           points: { advanced: 3, power: 1 } }
      ]
    },
    {
      question: 'What do you want most from a class?',
      answers: [
        { text: 'A quiet mind',                       points: { evening: 2, slow: 3 } },
        { text: 'Strength and stamina',               points: { power: 3, advanced: 2 } },
        { text: 'Better posture and flexibility',     points: { mobility: 3, morning: 1 } },
        { text: 'Energy for the day ahead',           points: { morning: 3, advanced: 1 } }
      ]
    },
    {
      question: 'When can you usually practise?',
      answers: [
        { text: 'Early morning, before work',         points: { morning: 3 } },
        { text: 'Weekday evenings',                   points: { power: 2, evening: 2, advanced: 1 } },
        { text: 'Late in the evening to unwind',      points: { evening: 3 } },
        { text: 'At the weekend',                     points: { slow: 2, mobility: 2, power: 1 } }
      ]
    }
  ];

  /* ---------- Quiz results: which class to recommend ---------- */
  L.data.results = [
    { key: 'morning',  name: 'Morning Flow',              classId: 'mon-morning',  text: 'You like to start the day by moving. This gentle vinyasa wakes up the spine and keeps the energy steady.' },
    { key: 'power',    name: 'Power Hatha',               classId: 'tue-power',    text: 'You want to feel strong. Long holds and standing poses will build stamina and focus.' },
    { key: 'evening',  name: 'Evening Restore',           classId: 'mon-evening',  text: 'Your day is loud, so your practice should be quiet. Supported poses and breathwork help you let go.' },
    { key: 'mobility', name: 'Mobility for Desk Workers', classId: 'sat-mobility', text: 'Your neck and back carry the workday. This class opens the shoulders, hips and spine.' },
    { key: 'slow',     name: 'Slow Sunday Flow',          classId: 'sun-slow',     text: 'You are looking for calm. A slow weekend flow with a long final rest is made for you.' },
    { key: 'advanced', name: 'Advanced Vinyasa',          classId: 'fri-vinyasa',  text: 'You have a steady practice and want a challenge. Expect flowing sequences and arm balances.' }
  ];

  /* ---------- Sample student reviews (fictional) ---------- */
  L.data.reviews = [
    { id: 1, name: 'Aruzhan K.', since: 'spring',  className: 'Mobility for Desk Workers', rating: 5, text: 'I came for my back pain and stayed because it is the only hour of my week when my phone is silent.' },
    { id: 2, name: 'Timur S.',   since: 'summer',  className: 'Power Hatha',               rating: 5, text: 'No mirrors and no competition. For the first time I enjoy exercise instead of counting the minutes.' },
    { id: 3, name: 'Kamila B.',  since: 'winter',  className: 'Evening Restore',           rating: 5, text: 'Madina’s voice and the soft light make the whole city disappear. I sleep better on Mondays.' },
    { id: 4, name: 'Daniyar M.', since: 'autumn',  className: 'Morning Flow',              rating: 4, text: 'Getting up at six was hard at first. Now Morning Flow is the best part of my week.' },
    { id: 5, name: 'Alina R.',   since: 'spring',  className: 'Slow Sunday Flow',          rating: 5, text: 'I was afraid I was not flexible enough. Nobody cared, and the teacher gave me an easier option every time.' },
    { id: 6, name: 'Nursultan A.', since: 'summer', className: 'Advanced Vinyasa',         rating: 5, text: 'Small groups mean real corrections. My handstand finally holds for ten breaths.' },
    { id: 7, name: 'Zhanna T.',  since: 'winter',  className: 'Evening Restore',           rating: 4, text: 'A calm place in the middle of a busy week. Mats and blankets are always clean and ready.' },
    { id: 8, name: 'Erlan D.',   since: 'autumn',  className: 'Power Hatha',               rating: 5, text: 'Dana explains why each pose matters. I feel stronger and my posture at work has changed.' }
  ];

  /* ---------- Membership plans ---------- */
  L.data.plans = [
    { id: 'dropin',    name: 'Drop-in',       tagline: 'One class, whenever you feel like it.', price: 4000,  unit: '',        featured: false, cta: 'Try a class',
      perks: ['Any class on the schedule', 'Mat and props included', 'First class free'] },
    { id: 'unlimited', name: 'Unlimited',     tagline: 'Practice as often as you like.',        price: 28000, unit: '/ month', featured: true,  cta: 'Join Liara',
      perks: ['Unlimited classes', 'Bring a friend once a month', 'Free breathwork workshop', 'Freeze for 7 days'] },
    { id: 'pass10',    name: '10-class pass', tagline: 'Flexible, valid for three months.',     price: 32000, unit: '',        featured: false, cta: 'Get a pass',
      perks: ['10 classes, any level', 'Share with a friend', 'Mat and props included'] }
  ];
})(window.Liara);
