/* =========================================================
   store.js — bookings made by the visitor.
   Saved in localStorage (with an in-memory fallback if the
   browser blocks storage) and shared by schedule and booking.
   ========================================================= */
window.Liara = window.Liara || {};

(function (L) {
  'use strict';

  var KEY = 'liara.bookings';
  var bookings = load();

  function load() {
    try {
      var saved = JSON.parse(window.localStorage.getItem(KEY));
      return Array.isArray(saved) ? saved : [];
    } catch (error) {
      return []; // storage blocked or corrupted: start empty
    }
  }

  function save() {
    try { window.localStorage.setItem(KEY, JSON.stringify(bookings)); } catch (error) { /* keep in memory */ }
    document.dispatchEvent(new CustomEvent('liara:bookings'));
  }

  L.store = {
    all: function () { return bookings.slice(); },

    add: function (booking) { bookings.push(booking); save(); },

    remove: function (ref) {
      bookings = bookings.filter(function (item) { return item.ref !== ref; });
      save();
    },

    // Places the visitor has already reserved in one session (class + date)
    takenByVisitor: function (classId, isoDate) {
      return bookings.reduce(function (sum, item) {
        return item.classId === classId && item.date === isoDate ? sum + item.spots : sum;
      }, 0);
    }
  };

  L.findClass = function (id) {
    return L.data.classes.filter(function (item) { return item.id === id; })[0] || null;
  };

  // Free places in a class on a given date.
  // The studio's own bookings are known only for the next session.
  L.spotsLeft = function (cls, isoDate) {
    var next = L.toISO(L.nextSession(cls.weekday, cls.time));
    var studioBooked = isoDate === next ? cls.booked : 0;
    return Math.max(0, cls.capacity - studioBooked - L.store.takenByVisitor(cls.id, isoDate));
  };
})(window.Liara);
