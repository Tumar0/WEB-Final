/* =========================================================
   main.js — shared namespace and helper functions.
   Loaded first on every page; all other scripts use window.Liara.
   ========================================================= */
window.Liara = window.Liara || {};

(function (L) {
  'use strict';

  /* ---- DOM helpers ---- */
  // Short querySelector helpers
  L.qs = function (selector, root) { return (root || document).querySelector(selector); };
  L.qsa = function (selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); };

  // Create an element: el('div', { class: 'card', text: 'Hi' }, [child1, child2])
  L.el = function (tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      var value = attrs[key];
      if (value === null || value === undefined || value === false) { return; }
      if (key === 'text') { node.textContent = value; }
      else if (key === 'class') { node.className = value; }
      else { node.setAttribute(key, value === true ? '' : value); }
    });
    (children || []).forEach(function (child) {
      if (child) { node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child); }
    });
    return node;
  };

  /* ---- Formatting helpers ---- */
  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  L.DAYS = DAYS;

  function pad(n) { return n < 10 ? '0' + n : String(n); }

  // Date -> "2026-11-16" (local time, not UTC)
  L.toISO = function (date) {
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
  };

  // "2026-11-16" -> Date at local midnight (or null if not a real date)
  L.parseISO = function (text) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text || '');
    if (!m) { return null; }
    var date = new Date(+m[1], +m[2] - 1, +m[3]);
    var real = date.getFullYear() === +m[1] && date.getMonth() === +m[2] - 1 && date.getDate() === +m[3];
    return real ? date : null;
  };

  // Date -> "Mon 16 Nov"
  L.shortDate = function (date) {
    return DAYS[date.getDay()].slice(0, 3) + ' ' + date.getDate() + ' ' + MONTHS[date.getMonth()];
  };

  // 28000 -> "28 000 ₸"
  L.money = function (amount) {
    return String(Math.round(amount)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ₸';
  };

  L.today = function () {
    var now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), now.getDate());
  };

  // Next date on which a weekly class (weekday 0-6, "HH:MM") takes place.
  L.nextSession = function (weekday, time) {
    var now = new Date();
    var date = L.today();
    var diff = (weekday - date.getDay() + 7) % 7;
    var parts = time.split(':');
    var startsToday = new Date(date.getFullYear(), date.getMonth(), date.getDate(), +parts[0], +parts[1]);
    if (diff === 0 && startsToday <= now) { diff = 7; } // today's class already started
    date.setDate(date.getDate() + diff);
    return date;
  };

  L.plural = function (n, one, many) { return n + ' ' + (n === 1 ? one : many); };

  L.reducedMotion = function () {
    return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  };


  /* ---- Persistent light / dark theme (shared by every page) ---- */
  L.initTheme = function () {
    var root = document.documentElement;
    var buttons = L.qsa('[data-theme-toggle]');
    function apply(theme) {
      root.dataset.theme = theme;
      buttons.forEach(function (button) {
        var dark = theme === 'dark';
        button.setAttribute('aria-pressed', String(dark));
        button.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
        button.innerHTML = dark ? '☀ <span>Light mode</span>' : '☾ <span>Dark mode</span>';
      });
      try { window.localStorage.setItem('liara.theme', theme); } catch (error) { /* theme still works for this visit */ }
    }
    var initial = root.dataset.theme === 'dark' ? 'dark' : 'light';
    apply(initial);
    buttons.forEach(function (button) {
      button.addEventListener('click', function () { apply(root.dataset.theme === 'dark' ? 'light' : 'dark'); });
    });
  };
  L.initTheme();

  /* ---- Footer year ---- */
  document.addEventListener('DOMContentLoaded', function () {
    L.qsa('[data-year]').forEach(function (node) { node.textContent = new Date().getFullYear(); });
  });
})(window.Liara);
