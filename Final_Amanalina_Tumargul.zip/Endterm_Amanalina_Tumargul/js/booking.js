/* =========================================================
   booking.js — booking form: validation, success message,
   and the "Your bookings" list.
   Errors are shown under each field (no alerts).
   ========================================================= */
(function (L) {
  'use strict';

  var form = L.qs('#bookingForm');
  if (!form) { return; }

  var success = L.qs('#formSuccess');
  var classSelect = form.elements.classId;
  var dateInput = form.elements.date;
  var MAX_NOTE = 300;
  var MAX_DAYS_AHEAD = 60;
  var MAX_SPOTS = 3;

  /* ---------- Fill the class list from data ---------- */
  L.data.classes.forEach(function (cls) {
    classSelect.appendChild(L.el('option', {
      value: cls.id,
      text: cls.day + ' ' + cls.time + ' — ' + cls.name + ' (' + cls.teacher + ')'
    }));
  });

  /* ---------- Date limits ---------- */
  var today = L.today();
  var lastDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + MAX_DAYS_AHEAD);
  dateInput.min = L.toISO(today);
  dateInput.max = L.toISO(lastDay);

  /* ---------- Validation rules ----------
     Every rule returns an error text, or '' when the value is fine. */
  var EMAIL = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;
  var PHONE = /^(\+7|8)7\d{9}$/;            // Kazakhstan mobile: +7 7xx xxx xx xx
  var NAME = /^[\p{L}][\p{L}\s'’-]*$/u;      // letters, spaces, apostrophe, hyphen

  var rules = {
    name: function () {
      var value = form.elements.name.value.trim();
      if (!value) { return 'Please tell us your name.'; }
      if (value.length < 2) { return 'Your name must have at least 2 letters.'; }
      if (!NAME.test(value)) { return 'Use letters only, without digits or symbols.'; }
      return '';
    },

    email: function () {
      var value = form.elements.email.value.trim();
      if (!value) { return 'Please enter your email.'; }
      if (!EMAIL.test(value)) { return 'This email looks incomplete. Example: name@mail.com'; }
      return '';
    },

    phone: function () {
      var value = form.elements.phone.value.replace(/[\s()-]/g, '');
      if (!value) { return 'Please enter your phone number.'; }
      if (!PHONE.test(value)) { return 'Use a Kazakhstan mobile number, for example +7 700 123 45 67.'; }
      return '';
    },

    classId: function () {
      return classSelect.value ? '' : 'Please choose a class.';
    },

    date: function () {
      var cls = L.findClass(classSelect.value);
      var date = L.parseISO(dateInput.value);
      if (!dateInput.value) { return 'Please pick a date.'; }
      if (!date) { return 'This is not a real date. Pick one from the calendar.'; }
      if (date < today) { return 'This date has already passed. Choose today or later.'; }
      if (date > lastDay) { return 'We take bookings up to ' + MAX_DAYS_AHEAD + ' days ahead.'; }
      if (cls && date.getDay() !== cls.weekday) {
        return cls.name + ' runs on ' + cls.day + 's. Please choose a ' + cls.day + '.';
      }
      return '';
    },

    spots: function () {
      var raw = form.elements.spots.value.trim();
      var n = Number(raw);
      if (!raw) { return 'Enter how many spots you need (1–' + MAX_SPOTS + ').'; }
      if (!Number.isInteger(n) || n < 1 || n > MAX_SPOTS) { return 'Choose a whole number from 1 to ' + MAX_SPOTS + '.'; }

      var cls = L.findClass(classSelect.value);
      var date = L.parseISO(dateInput.value);
      if (cls && date) {
        var left = L.spotsLeft(cls, L.toISO(date));
        if (left === 0) { return 'This session is full. Pick another date or class.'; }
        if (n > left) { return 'Only ' + L.plural(left, 'spot is', 'spots are') + ' left for this session.'; }
      }
      return '';
    },

    level: function () {
      return form.elements.level.value ? '' : 'Please tell us your experience.';
    },

    agree: function () {
      return form.elements.agree.checked ? '' : 'Please confirm so we can contact you.';
    }
  };

  var order = ['name', 'email', 'phone', 'classId', 'date', 'spots', 'level', 'agree'];

  /* ---------- Show / clear an error under a field ---------- */
  function setError(field, message) {
    var wrapper = form.querySelector('[data-field="' + field + '"]');
    var feedback = wrapper.querySelector('.invalid-feedback');
    var inputs = L.qsa('input, select, textarea', wrapper);

    feedback.textContent = message;
    feedback.classList.toggle('d-block', !!message);
    inputs.forEach(function (input) {
      input.classList.toggle('is-invalid', !!message);
      if (message) { input.setAttribute('aria-invalid', 'true'); } else { input.removeAttribute('aria-invalid'); }
    });
  }

  function validate(field) {
    var message = rules[field]();
    setError(field, message);
    return message === '';
  }

  function clearAllErrors() {
    order.forEach(function (field) { setError(field, ''); });
  }

  /* ---------- Date hint under the date field ---------- */
  var hint = L.qs('#dateHint');

  function updateHint() {
    var cls = L.findClass(classSelect.value);
    if (!cls) { hint.textContent = ''; return; }
    var next = L.nextSession(cls.weekday, cls.time);
    var left = L.spotsLeft(cls, L.toISO(next));
    hint.textContent = 'Next ' + cls.day + ': ' + L.shortDate(next) + ' · ' +
      (left === 0 ? 'full' : L.plural(left, 'spot', 'spots') + ' left');
  }

  // When the class changes, suggest the next matching date
  function suggestDate() {
    var cls = L.findClass(classSelect.value);
    if (!cls) { return; }
    var current = L.parseISO(dateInput.value);
    if (!current || current.getDay() !== cls.weekday || current < today) {
      dateInput.value = L.toISO(L.nextSession(cls.weekday, cls.time));
    }
    updateHint();
  }

  /* ---------- Note counter ---------- */
  var note = form.elements.note;
  var counter = L.qs('#noteCount');
  function updateCounter() { counter.textContent = note.value.length + ' / ' + MAX_NOTE; }
  note.maxLength = MAX_NOTE;

  /* ---------- Events ---------- */
  // Re-check a field that already shows an error, so the message disappears as soon as it is fixed
  function recheck(event) {
    var target = event.target;
    var wrapper = target.closest('[data-field]');
    if (!wrapper || !rules[wrapper.getAttribute('data-field')]) { return; } // the note is optional
    var field = wrapper.getAttribute('data-field');
    // A date picked from the calendar is checked at once (the date field has no "leave" moment while typing)
    var pickedDate = event.type === 'change' && target.type === 'date' && target.value !== '';
    if (target.classList.contains('is-invalid') || pickedDate) { validate(field); }
    // Class and date depend on each other and on the number of spots
    if (field === 'classId' || field === 'date') {
      ['date', 'spots'].forEach(function (name) {
        if (name !== field && form.querySelector('[data-field="' + name + '"] .is-invalid')) { validate(name); }
      });
    }
  }
  form.addEventListener('input', recheck);
  form.addEventListener('change', recheck);

  // Check a field when the visitor leaves it (only if something was typed)
  form.addEventListener('focusout', function (event) {
    var target = event.target;
    var wrapper = target.closest('[data-field]');
    if (!wrapper || !rules[wrapper.getAttribute('data-field')] || target.type === 'radio' || target.type === 'checkbox' || target.tagName === 'SELECT') { return; }
    if (target.value !== '') { validate(wrapper.getAttribute('data-field')); }
  });

  classSelect.addEventListener('change', suggestDate);
  note.addEventListener('input', updateCounter);

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var firstInvalid = null;
    order.forEach(function (field) {
      if (!validate(field) && !firstInvalid) { firstInvalid = field; }
    });

    if (firstInvalid) {
      var wrapper = form.querySelector('[data-field="' + firstInvalid + '"]');
      wrapper.querySelector('input, select, textarea').focus();
      return;
    }
    confirmBooking();
  });

  /* ---------- Successful booking ---------- */
  function confirmBooking() {
    var cls = L.findClass(classSelect.value);
    var date = L.parseISO(dateInput.value);
    var booking = {
      ref: 'LRA-' + Date.now().toString(36).slice(-5).toUpperCase(),
      classId: cls.id,
      date: L.toISO(date),
      spots: Number(form.elements.spots.value),
      name: form.elements.name.value.trim(),
      email: form.elements.email.value.trim()
    };
    L.store.add(booking);

    success.textContent = '';
    success.appendChild(L.el('strong', { text: 'Thank you, ' + booking.name.split(/\s+/)[0] + '! Your spot is reserved.' }));
    success.appendChild(L.el('span', {
      class: 'd-block',
      text: cls.name + ' · ' + L.shortDate(date) + ' at ' + cls.time + ' · ' + L.plural(booking.spots, 'spot', 'spots') +
            '. Reference ' + booking.ref + '. A confirmation was sent to ' + booking.email + '.'
    }));

    form.reset();
    clearAllErrors();
    hint.textContent = '';
    updateCounter();

    // jQuery effect: the message slides in, then the visitor sees it
    window.jQuery(success).stop(true, true).hide().slideDown(300);
    success.focus();
  }

  /* ---------- "Your bookings" list ---------- */
  var list = L.qs('#myBookings');
  var emptyText = L.qs('#myBookingsEmpty');
  var totalText = L.qs('#myBookingsTotal');

  function renderBookings() {
    var items = L.store.all();
    list.textContent = '';
    emptyText.hidden = items.length > 0;
    totalText.hidden = items.length === 0;

    var spots = 0;
    items.forEach(function (item) {
      var cls = L.findClass(item.classId);
      var date = L.parseISO(item.date);
      if (!cls || !date) { return; }
      spots += item.spots;

      var cancel = L.el('button', {
        type: 'button', class: 'btn-link-liara', 'data-ref': item.ref,
        'aria-label': 'Cancel booking ' + item.ref + ', ' + cls.name,
        text: 'Cancel'
      });
      list.appendChild(L.el('li', { class: 'my-booking', 'data-ref': item.ref }, [
        L.el('div', {}, [
          L.el('strong', { text: cls.name }),
          L.el('span', { class: 'd-block small', text: L.shortDate(date) + ' · ' + cls.time + ' · ' + L.plural(item.spots, 'spot', 'spots') }),
          L.el('span', { class: 'd-block small ref', text: item.ref })
        ]),
        cancel
      ]));
    });
    totalText.textContent = L.plural(items.length, 'booking', 'bookings') + ' · ' + L.plural(spots, 'spot', 'spots') + ' in total';
  }

  list.addEventListener('click', function (event) {
    var button = event.target.closest('button[data-ref]');
    if (!button || button.disabled) { return; }
    button.disabled = true; // a fast second click cannot cancel twice
    var ref = button.getAttribute('data-ref');
    window.jQuery(button.closest('li')).slideUp(250, function () { L.store.remove(ref); });
  });

  document.addEventListener('liara:bookings', function () {
    renderBookings();
    updateHint();
  });

  /* ---------- Choose a class from the timetable or from a link ---------- */
  function chooseClass(id) {
    if (!L.findClass(id)) { return; }
    classSelect.value = id;
    suggestDate();
    setError('classId', '');
    if (typeof L.scrollTo === 'function') { L.scrollTo('#booking', function () { classSelect.focus(); }); }
    else { classSelect.focus(); }
  }

  document.addEventListener('liara:choose-class', function (event) { chooseClass(event.detail.id); });

  var preset = new URLSearchParams(window.location.search).get('class');
  if (preset) { classSelect.value = L.findClass(preset) ? preset : ''; suggestDate(); }

  updateCounter();
  renderBookings();
})(window.Liara);
