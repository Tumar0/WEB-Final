/* =========================================================
   effects.js — jQuery effects shared by both pages:
   1. smooth scroll to anchors          4. back-to-top button (fade)
   2. FAQ accordion (slideUp/slideDown)  5. scroll reveal
   3. animated counters                  6. breathing pause button
   ========================================================= */
(function (L, $) {
  'use strict';

  var HEADER_GAP = 16;

  function headerHeight() { return $('.site-header').outerHeight() || 0; }

  /* ---------- 1. Smooth scroll ---------- */
  // Exposed so other scripts (booking.js) can use it too
  L.scrollTo = function (selector, done) {
    var $target = $(selector);
    if (!$target.length) { return; }
    var top = Math.max(0, $target.offset().top - headerHeight() - HEADER_GAP);
    var finish = function () {
      if (!$target.is('a, button, input, select, textarea, [tabindex]')) { $target.attr('tabindex', '-1'); }
      $target[0].focus({ preventScroll: true });
      if (typeof done === 'function') { done(); }
    };
    if (L.reducedMotion()) { window.scrollTo(0, top); finish(); return; }
    $('html, body').stop(true).animate({ scrollTop: top }, 600, 'swing', finish);
  };

  $(document).on('click', 'a[href*="#"]', function (event) {
    var link = this;
    var samePage = link.pathname.replace(/^\//, '') === window.location.pathname.replace(/^\//, '') && link.hostname === window.location.hostname;
    if (!samePage || !link.hash || link.hash === '#') { return; }
    if (!$(link.hash).length) { return; }
    event.preventDefault();
    L.scrollTo(link.hash);
    if (window.history && window.history.replaceState) { window.history.replaceState(null, '', link.hash); }
    closeMobileMenu();
  });

  // On phones the menu is a Bootstrap collapse: close it after choosing a link
  function closeMobileMenu() {
    var menu = document.getElementById('mainNav');
    var instance = menu && window.bootstrap ? window.bootstrap.Collapse.getInstance(menu) : null;
    if (instance && menu.classList.contains('show')) { instance.hide(); }
  }

  // Page opened with #booking etc. (coming from the Home page)
  $(window).on('load', function () {
    if (window.location.hash && $(window.location.hash).length) {
      window.setTimeout(function () { L.scrollTo(window.location.hash); }, 150);
    }
  });

  /* ---------- 2. FAQ accordion ---------- */
  $('.faq-btn').on('click', function () {
    var $button = $(this);
    var $item = $button.closest('.faq-item');
    var $panel = $('#' + $button.attr('aria-controls'));
    var opening = !$item.hasClass('is-open');

    // close the others
    $('.faq-item.is-open').not($item).each(function () {
      $(this).removeClass('is-open').find('.faq-btn').attr('aria-expanded', 'false');
      $(this).find('.faq-panel').stop(true, true).slideUp(250);
    });

    $item.toggleClass('is-open', opening);
    $button.attr('aria-expanded', opening ? 'true' : 'false');
    // stop(true, true) makes fast repeated clicks finish the previous animation first
    if (opening) { $panel.stop(true, true).slideDown(250); } else { $panel.stop(true, true).slideUp(250); }
  });

  /* ---------- 3. Animated counters ---------- */
  function countUp(node) {
    var $node = $(node);
    var target = Number($node.attr('data-count'));
    if (!isFinite(target) || L.reducedMotion()) { $node.text(target); return; }
    $({ n: 0 }).animate({ n: target }, {
      duration: 1400,
      easing: 'swing',
      step: function (now) { $node.text(Math.round(now)); },
      complete: function () { $node.text(target); }
    });
  }

  /* ---------- 5. Scroll reveal (+ starts the counters) ---------- */
  function reveal(node) {
    node.classList.add('visible');
    $(node).find('[data-count]').each(function () { countUp(this); });
  }

  function watchRevealed() {
    var nodes = L.qsa('.reveal:not(.visible)');
    if (!('IntersectionObserver' in window)) { nodes.forEach(reveal); return; }
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { reveal(entry.target); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    nodes.forEach(function (node) { observer.observe(node); });
  }

  /* ---------- 4. Back-to-top button ---------- */
  var $top = $('<button type="button" class="back-top" aria-label="Back to top">↑</button>').hide().appendTo('body');
  var topVisible = false;
  $(window).on('scroll', function () {
    var show = $(window).scrollTop() > 600;
    if (show === topVisible) { return; }
    topVisible = show;
    if (show) { $top.stop(true, true).fadeIn(200); } else { $top.stop(true, true).fadeOut(200); }
  });
  $top.on('click', function () {
    if (L.reducedMotion()) { window.scrollTo(0, 0); } else { $('html, body').stop(true).animate({ scrollTop: 0 }, 500); }
    $('.navbar-brand').first().trigger('focus');
  });

  /* ---------- 6. Breathing guide: pause / play ---------- */
  $('#breathToggle').on('click', function () {
    var $button = $(this);
    var paused = !$('.breath').hasClass('is-paused');
    $('.breath').toggleClass('is-paused', paused);
    $button.attr('aria-pressed', paused ? 'true' : 'false').text(paused ? 'Resume breathing guide' : 'Pause breathing guide');
  });

  $(function () {
    // wait one tick so scripts that build cards (home.js, plans.js) are finished
    window.setTimeout(watchRevealed, 0);
  });
})(window.Liara, window.jQuery);
