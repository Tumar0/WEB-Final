# Liara Yoga Studio — Final Project

WEB Technologies 1 (Front End). Student: Tumargul Amanalina, group IT-2511.
Live site: https://tumar0.github.io/Midterm/

A two-page website for a fictional yoga studio in Astana (the Midterm site, now a working product).

## Final release additions since Endterm
- Persistent light/dark mode toggle in the navigation on every page (saved in localStorage).
- Improved keyboard focus visibility and dark-mode form/card styling.
- Existing booking data remains saved as JSON in localStorage and is shared across the pages.

## What a visitor can do
- **Home:** take a 4-question class finder quiz, read a reviews slider, pause the breathing guide.
- **Classes & Booking:** search, filter and sort the timetable, compare membership prices with a calculator,
  and book a class with a validated form. Bookings are kept in the browser (localStorage) and can be cancelled.

## Structure
```
index.html, classes.html
css/style.css
js/main.js      shared helpers
js/data.js      all content arrays (classes, practices, quiz, reviews, plans)
js/store.js     bookings in localStorage, free spots
js/schedule.js  timetable search / filter / sort
js/plans.js     plan cards + price calculator
js/booking.js   form validation, success message, "Your bookings"
js/quiz.js      class finder quiz
js/home.js      practice cards, stats, reviews slider
js/effects.js   jQuery effects (smooth scroll, accordion, counters, back-to-top, reveal)
images/favicon.svg
```

## Credits
Google Fonts (Fraunces, Manrope) · Bootstrap 5.3.3 · jQuery 3.7.1 ·
code and report prepared with AI assistance (ChatGPT); teacher portraits are stock photos found on the internet (illustrative). Reviews and names are fictional.
